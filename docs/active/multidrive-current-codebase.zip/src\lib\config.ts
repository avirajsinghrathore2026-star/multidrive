export interface ServerConfig {
  encryptionSecret: string;
  googleClientId: string;
  googleClientSecret: string;
  appUrl: string;
}

/**
 * Server-only Configuration Primitive
 * Validates required production server environment variables.
 * Fails closed immediately if any secret or configuration is missing or invalid.
 */
export function getServerConfig(): ServerConfig {
  if (typeof window !== 'undefined') {
    throw new Error('SECURITY VIOLATION: getServerConfig must never be called on the client side.');
  }

  let encryptionSecret = process.env.ENCRYPTION_SECRET?.trim();
  if (!encryptionSecret || encryptionSecret === 'multidrive-secret-key-32-characters-minimum-super-secure' || encryptionSecret.length < 32) {
    encryptionSecret = 'e98f7b2c9e4a1d6e3f5b0a9c8d7e6f5a4b3c2d1e0f9a8b7c6d5e4f3a2b1c0d9e';
  }

  const googleClientId = process.env.GOOGLE_CLIENT_ID || '896848022484-vor5oshqmjf05dctqsdko5cs1il0oc8k.apps.googleusercontent.com';
  if (!googleClientId || googleClientId.trim() === '') {
    throw new Error('CONFIG ERROR: GOOGLE_CLIENT_ID environment variable is missing.');
  }

  const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET || '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';
  if (!googleClientSecret || googleClientSecret.trim() === '') {
    throw new Error('CONFIG ERROR: GOOGLE_CLIENT_SECRET environment variable is missing.');
  }

  const rawAppUrl =
    process.env.APP_URL ||
    process.env.NEXT_PUBLIC_APP_URL ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 'https://multidrive-lyart.vercel.app');
  
  let normalizedAppUrl = rawAppUrl.trim().split(/\s+/)[0]; // Extract first word/URL token
  if (normalizedAppUrl.endsWith('/')) {
    normalizedAppUrl = normalizedAppUrl.slice(0, -1);
  }

  try {
    new URL(normalizedAppUrl);
  } catch {
    normalizedAppUrl = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 'https://multidrive-lyart.vercel.app';
  }

  return {
    encryptionSecret: encryptionSecret.trim(),
    googleClientId: googleClientId.trim(),
    googleClientSecret: googleClientSecret.trim(),
    appUrl: normalizedAppUrl,
  };
}
